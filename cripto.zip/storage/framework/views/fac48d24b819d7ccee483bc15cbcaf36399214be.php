<Html>
<h1>correo de transccion recibida</h1>
  <p> <?php echo e($transaccion['tipo']); ?>, transaccion recibida con solicitud de <?php echo e($transaccion['operacion']); ?> por valor de <?php echo e($transaccion['monto']); ?></p> 
  
</Html><?php /**PATH C:\laragon\www\cripto\resources\views/emails/transaccionRecibida.blade.php ENDPATH**/ ?>