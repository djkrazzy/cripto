

<?php $__env->startSection('content'); ?>


			<section class="login bluish-purple relative overflow-h ptb-100">
				<div class="container">
					<div class="row">
						<div class="col-xl-12 col-lg-12 col-md-12">
							<div class="user-table">
								<div class="section-heading text-center">
									<h2 class="title">Ingreso</h2>
								</div>
								<form class="login-form"  method='POST' >
                                 <?php echo csrf_field(); ?>
									<div class="form-group">
										<label class="form-label">Email address</label>
										<input name="email" type="text" class="form-control" placeholder="Email Address" required="">
										<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<small class="text-danger">  <?php echo e($message); ?> </small>
								<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>
									<div class="form-group">
										<label class="form-label">Password</label>
										<input name='password' type="password" class="form-control" placeholder="Enter your Password" required="">
										<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<small class="text-danger">  <?php echo e($message); ?> </small>
								<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								<?php if(session('info')): ?>
												<small class="text-danger">  <?php echo e(session('info')); ?> </small>
												
												<?php endif; ?>
									</div>
									<div class="login-btn-g">
										<div class="row">
											<div class="col-7 d-flex flex-center">
												<div class="check-box">
													<span>
										                <input type="checkbox" class="checkbox" id="account" name="remember">
										                <label for="account">Recuerdame</label>
										            </span>
									            </div>
									        </div>
									        <div class="col-5 d-flex flex-center justify-right">
									           
												
<button name="submit" type="submit" class="button">Log In</button>
									        </div>
									    </div>
							        </div>
							        <div class="text-center">
							        	<a title="Forgot Password" class="link forgot-password mtb-20" href="#">Forgot your password?</a>
							        </div>
							        <div class="new-account text-center mt-20"> 
							        	<span>Don't have an account?</span> 	
						                <a class="link" title="Create New Account" href="<?php echo e(route('registro')); ?>">Creat una cuenta</a> 
						            </div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</section>






            
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php echo e(__('You are logged in!')); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cripto\resources\views/home/login.blade.php ENDPATH**/ ?>