<Html>
<h1>correo de transccion recibida</h1>
  <p> {{ $transaccion['tipo']}}, transaccion recibida con solicitud de {{ $transaccion['operacion']}} por valor de {{ $transaccion['monto']}}</p> 
  
</Html>